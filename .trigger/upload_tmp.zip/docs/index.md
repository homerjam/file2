Docs
====

This is where you should document your module.

You can create other .md files in this folder, or even more folders containing index.md and other .md files.

You can also include `.jpg`, `.gif`, and `.png` files if you would like to use images.